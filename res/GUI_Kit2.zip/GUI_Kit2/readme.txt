
-----------------------------------------------------------------------------------
This free file was created by and offered by Jonathan Atkinson - PixelatedMinds.com
-----------------------------------------------------------------------------------


TERMS OF USE:
-----------------------------------------------------------------------------------

 Nothing complicated but you should certainly be aware that this is a legal obligation you are agreeing to if you download and use any of my free files.

- You are free to use any and all elements contained within the free files for your own personal or commercial projects.

- Attribution is not necessary but is always welcomed – helping to spread the word is always the proper thing to do.

- You cannot redistribute my files “as is”, wether that is for free or paid.

- Please do not link directly to downloads in any way, if you wish to promote a file on another site please do so by offering a link to the post or the site but not the download file itself.

- You may freely use any and all preview images, or, screenshots of PixelatedMinds.com without for promotional purposes (promotional as in promoting this site or it’s files) as long as they are not defaced / altered in any way.


-----------------------------------------------------------------------------------
Jonathan Atkinson
-----------------------------------------------------------------------------------

www.pixelatedminds.com
twitter: @twsjonathan
ThemeForest: http://themeforest.net/user/jonathan01